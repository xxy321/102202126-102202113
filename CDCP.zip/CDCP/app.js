// app.js
App({
  onLaunch() {
    
    wx.cloud.init({
      env:"bsgm-5gvcl7jl192b36ae"
    })
    if(wx.getStorageSync('userInfo')){
      this.globalData.userInfo = wx.getStorageSync('userInfo')
      console.log('get storage')
    }
  },
  globalData: {
    userInfo: null
  }
})
